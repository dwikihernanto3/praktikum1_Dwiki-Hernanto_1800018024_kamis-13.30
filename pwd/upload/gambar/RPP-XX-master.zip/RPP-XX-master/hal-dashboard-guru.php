<?php
include "header.php";
?>


<head>
  <title>Login | Aplikasi Managemen Surat - Sd Impres Birobuli</title>
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendor/linearicons/style.css">
	<link rel="stylesheet" href="assets/vendor/chartist/css/chartist-custom.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
  <link rel="apple-touch-icon" sizes="100x100" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" sizes="150x150" href="assets/img/almujahid.png">
</head>

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> 
     <script src="js/jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>

.panel-heading{
	height: 50px;
	font-size: 20px;
	font-family: arial;
}
.main-content .table{
	font-size: 13px;
	font-family: arial;
}
.form-control{
  border-radius: 0;
}
.row {
  margin-top: 20px;
  margin-left: 20px;
  position: cover;
}
.form-control{
  border-radius: 0;
}
table { 
  width: 100%; 
  border-collapse: collapse; 
}
/* Zebra striping */
tr:nth-of-type(odd) { 
  background: #eee; 
}
th { 
  background: #FFF; 
  color: black; 
  font-weight: bold; 
}
td, th { 
  padding: 6px; 
  border: 1px solid #ccc; 
  text-align: left; 
  color : black;
}
@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #fff; 
		position: relative;
		padding-left: 50%; 
    
	}
	
	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
	}
	
	/*
	Label the data
	*/

}
</style>
<div class="main">
    <div class="main-content">
            <div class="container-fluid">
<div class="main-content">
<div class="panel panel-info">
  <div class="panel-heading">
    <h1 class="panel-title" style="color:black; margin-top:7px; font-family:tahoma; "></h1>
    
  </div>
  <div class="row">
      <button type="submit" class="btn btn-info" data-toggle="modal" data-target="#myModal"><i class="lnr lnr-plus-circle"></i>&nbsp&nbspBuat RPP</button>&nbsp&nbsp
       <a class='btn btn-success' href='#'><i class="fa fa-file-excel-o" aria-hidden="true"></i>&nbsp&nbspDownload Excel</a> &nbsp&nbsp <a class='btn btn-danger' href='#'><i class="fa fa-file-pdf-o" aria-hidden="true"></i>&nbsp&nbspDownload PDF</a>
     
      </div>

              <div class="panel">
                <div class="panel-body">
                   <table class="table caption-top">
                   <thead>
                   
                    <tr>
                        <th scope="col"><center>No</center></th>
                        <th scope="col"><center>MATERI PRODUK</center></th>
                        <th scope="col"><center>DI UNGGAH OLEH</center></th>
                        <th scope="col"><center>PELAJARAN</center></th>
                        <th scope="col" ><center>KELAS</center></th>
                        <th scope="col"><center>STATUS</center></th>
                        <th scope="col"><center>CETAK</center></th>
                        <th scope="col"><center>UBAH</center></th>
                        <th scope="col"><center>HAPUS</center></th>
                    </tr>
</thead>
                    <tbody>
                    <tr>
      <td scope="row"><center>1</center></td>
      <td><center>Bahasa Inggirs</center></td>
      <td><center>Tri Bima Sakty</center></td>
      <td><center>Pancasila</center></td>
      <td><center>XI</center></td>
      <td><center><span class="badge rounded-pill bg-success text-dark">DI TERIMA</span></center></td>
      <td><center><span class="badge rounded-pill bg-dark">CETAK</span></center></td>
      <td><center><span class="badge rounded-pill bg-secondary">UBAH</span></center></td>
      <td><center><span class="badge rounded-pill bg-danger"><i class="lnr lnr-trash"></i></span></center></td>
      
    </tr>
</tbody>
  </div>
</div>
</div></div>
</div>
</div>
</div>
</div>



<br><br>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="myModalLabel">Isi Data Surat Masuk</h5>
<form enctype="multipart/form-data"  class="form-horizontal" action="" method="post">

<div class="form-group">
          <label class="col-sm-3 control-label">Nomor Surat :</label>
          <div class="col-sm-6">
            <input type="text" name="no_surat" value="" class="form-control" requied="requied">
          </div>
        </div>
<br>
<br>
<br>

        <div class="form-group">
          <label class="col-sm-3 control-label">Surat Dari  :</label>
          <div class="col-sm-6">
            <input type="text" name="nama_surat"  class="form-control" required>
          </div>
        </div>
<br>
<br>
<br>

        <div class="form-group">
          <label class="col-sm-3 control-label">Perihal/Tentang Surat :</label>
          <div class="col-sm-6">
                    <select name="perihal" class="form-control">

                    <option value="Surat Keputusan">Surat Keputusan</option>
                    <option value="Surat Permohonan">Surat Permohonan</option>
                    <option value="Surat Perintah">Surat Perintah</option>
                    <option value="Surat Pengantar">Surat Pegantar</option>
                    <option value="Surat Edaran">Surat Edaran</option>
                    <option value="Surat Undangan">Surat Undangan</option>
                    <option value="dll">Dan Lain - Lain</option>

                   </select>
                   <textarea type="text" name="tambahan_ket"  class="form-control" required> </textarea>
          </div>
        </div>
        <br>
<br>
<br>
<br>


        <div class="form-group">
          <label class="col-sm-3 control-label">Tanggal Surat:</label>
          <div class="col-sm-6">
            <input type="date" name="tanggal_surat"  class="form-control" required >
          </div>
        </div>
<br>
<br>
<br>

        <div class="form-group">
          <label class="col-sm-3 control-label">Pengirim Surat:</label>
          <div class="col-sm-6">
            <input type="text" name="pengirim_surat"  class="form-control" required >
          </div>
        </div>
<br>
<br>
<br>

        <div class="form-group">
          <label class="col-sm-3 control-label">Di tujukan ke siapa  :</label>
          <div class="col-sm-6">
            <textarea type="text" name="keterangan"  class="form-control" required> </textarea>
          </div>
        </div>

<br>
<br>
<br>


                <div class="form-group">
          <label class="col-sm-3 control-label">Lokasi Arsip :</label>
          <div class="col-sm-6">
            <input type="text" name="lokasi"  class="form-control" required>
          </div>
        </div>  
        <br>
        <br>
       

              <div class="form-group">
              <label class="col-sm-3 control-label">Status :</label>
              <div class="col-sm-6">
              <select name="status" class="form-control">

                  <option value="Diterima">Diterima</option>
                  <option value="ditunda">ditunda</option>


                  </select>

              </div>
            </div>
<br><br>
          <div class="form-group">
          <label class="col-sm-3 control-label">Upload File :</label>
          <div class="col-sm-6">
            <input type="file" name="avatar"  class="form-control" id="avatar" required>
          </div>
        </div>  
        </div>
        <br>
        <br>
              
                    <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="kirim" value="Simpan">
      </div>
      </form>

</div>



    </div>
</div>
</div>  

</html>